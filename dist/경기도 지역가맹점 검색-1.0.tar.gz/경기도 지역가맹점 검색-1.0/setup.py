from distutils.core import setup


setup(name="경기도 지역가맹점 검색",version='1.0',py_modules=['UI','teller','noti','Gmail','mysmtplib'])
